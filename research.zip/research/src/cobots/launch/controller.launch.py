import os

from launch import LaunchDescription
from launch_ros.parameter_descriptions import ParameterValue
from launch.substitutions import Command
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_path

def generate_launch_description():
    common_controller = Node(
            package='cobots',
            executable='my_node',
            name='my_node',
            output='screen'
            )
    robo1 = {'trans_x': 0.5, 'trans_y': 0, 'trans_z':0, 'ang_x': 0.5, 'ang_y': 0, 'ang_z': 0.25}
    #ros2 topic pub /robo2/robo_speed geometry_msgs/msg/Twist "{linear: {x: 0.5, y: 0, z: 0}, angular: {x: 0, y: 0, z: -0.25}}"
    robo1_twist = (
        f"{{linear: {{x: {robo1['trans_x']}, y: {robo1['trans_y']}, z: {robo1['trans_z']}}}, "
        f"angular: {{x: {robo1['ang_x']}, y: {robo1['ang_y']}, z: {robo1['ang_z']}}}}}"
    )

    robo1_pub = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub', '/robo1/robo_speed',
            'geometry_msgs/msg/Twist',
            robo1_twist,
            '--rate', '10.0', '--once'   # for continuous publishing
        ],
        output='screen',
    )

    robo2 = {'trans_x': 0.5, 'trans_y': 0, 'trans_z':0, 'ang_x': 0.5, 'ang_y': 0, 'ang_z': -0.25}
    #ros2 topic pub /robo2/robo_speed geometry_msgs/msg/Twist "{linear: {x: 0.5, y: 0, z: 0}, angular: {x: 0, y: 0, z: -0.25}}"
    robo2_twist = (
        f"{{linear: {{x: {robo2['trans_x']}, y: {robo2['trans_y']}, z: {robo2['trans_z']}}}, "
        f"angular: {{x: {robo2['ang_x']}, y: {robo2['ang_y']}, z: {robo2['ang_z']}}}}}"
    )

    robo2_pub = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub', '/robo2/robo_speed',
            'geometry_msgs/msg/Twist',
            robo2_twist,
            '--rate', '10.0', '--once'
        ],
        output='screen',
    )

    
    return LaunchDescription([
        # common_controller
        robo1_pub,
        robo2_pub,
    ])