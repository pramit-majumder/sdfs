import os

from launch import LaunchDescription
from launch_ros.parameter_descriptions import ParameterValue
from launch.substitutions import Command, PathJoinSubstitution
from launch.actions import IncludeLaunchDescription, ExecuteProcess, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_path


def generate_launch_description():
    cobots_share = get_package_share_path('cobots')

    xacro_file = os.path.join(cobots_share, 'car.urdf.xacro')
    urdf_file = os.path.join(cobots_share, 'car.urdf')

    world_path = os.path.join(cobots_share, 'world.world')

    print(world_path)

    # expand xacro -> URDF once at launch start
    generate_urdf = ExecuteProcess(
        cmd=['xacro', xacro_file, '-o', urdf_file],
        output='screen'
    )

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file]),
        value_type=str
    )

    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description}],
        output='screen',
    )

    rsp1 = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        namespace='robo1',
        parameters=[{'robot_description': robot_description}],
        output='screen',
    )
    rsp2 = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        namespace='robo2',
        parameters=[{'robot_description': robot_description}],
        output='screen',
    )

    gazebo_launch_file = os.path.join(
        get_package_share_path('gazebo_ros'),
        'launch',
        'gazebo.launch.py'
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(gazebo_launch_file),
    #     launch_arguments={
    #         'world': PathJoinSubstitution([FindPackageShare('cobots'), "world.world"])
    #     }
    )

    world_arg = DeclareLaunchArgument(
        name='world',
        default_value=world_path,
        description='Path to the Gazebo world file'
    )

    spawn1 = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        # namespace='robo1',
        arguments=[
            '-entity', 'robot1',
            # '-topic', '/robo1/robot_description',
            '-topic', '/robot_description',
            # '-robot_namespace', 'robo1',
            '-x', '0',
            '-y', '-2',
            '-z', '0.0'
        ],
        output='screen'
    )

    spawn2 = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        namespace='robo2',
        arguments=[
            '-entity', 'robot2',
            '-topic', '/robo2/robot_description',
            '-robot_namespace', 'robo2',
            '-x', '2.0',
            '-y', '2',
            '-z', '0.0'
        ],
        output='screen'
    )

    spawn = [
        spawn1
        # ,spawn2
        ]

    return LaunchDescription([
        generate_urdf,
        world_arg,
        rsp,
        # rsp1,
        # rsp2,
        gazebo,
        *spawn
    ])
